Для локального закпуска создайте в корне файл .env.local
добавте в него URI вашей базы mongodb
пример MONGODB_URI=mongodb+srv://<username>:<password>@pastebin.xxx.mongodb.net/<dbname>?retryWrites=true&w=majority&appName=PasteBin

const { MongoClient, ServerApiVersion } = require('mongodb');
const uri = "mongodb+srv://spamsevstar:xPySkjMmXqg8uP5H@pastebin.zs7mxiq.mongodb.net/?retryWrites=true&w=majority&appName=PasteBin";

// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
serverApi: {
version: ServerApiVersion.v1,
strict: true,
deprecationErrors: true,
}
});

async function run() {
try {
// Connect the client to the server (optional starting in v4.7)
await client.connect();
// Send a ping to confirm a successful connection
await client.db("admin").command({ ping: 1 });
console.log("Pinged your deployment. You successfully connected to MongoDB!");
} finally {
// Ensures that the client will close when you finish/error
await client.close();
}
}
run().catch(console.dir);
